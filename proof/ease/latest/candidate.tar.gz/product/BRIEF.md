# Product brief

## Primary job

Carry one bounded user intention to a reviewed and verified artifact.

## Product promise

Carry the user from intent to one reviewed, durable, verifiable result without exposing the underlying agent and backend plumbing.

## Completion

The case is complete only when a canonical artifact exists, every material proposal has a decision, unresolved limitations are visible, and a receipt has been issued.
