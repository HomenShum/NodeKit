import { createMemoryCaseflow } from "@homenshum/nodekit/caseflow";

export const stages = Object.freeze([
  { id: "intake", label: "Confirm the intended outcome", owner: "user" },
  { id: "working", label: "Prepare a proposal", owner: "agent" },
  { id: "review", label: "Review the proposed change", owner: "user" },
  { id: "complete", label: "Verify and export", owner: "system" },
]);

export function createGuidedDemo(options = {}) {
  const runtime = createMemoryCaseflow(options);

  function start() {
    const work = runtime.createCase({
      primaryJob: "Carry one bounded user intention to a reviewed and verified artifact.",
      title: "Factory Domain Blank Base case",
    });
    const run = runtime.startRun({ caseId: work.caseId, stages });
    const artifact = runtime.createArtifact({
      caseId: work.caseId,
      content: { summary: "The last approved result remains here.", status: "baseline" },
      kind: "structured-document",
      runId: run.runId,
      title: "Primary artifact",
    });
    return { artifact, case: work, run };
  }

  function propose({ artifactId, runId, outcome }) {
    const artifact = runtime.snapshot().artifacts.find((entry) => entry.artifactId === artifactId);
    const confirmedOutcome = outcome ?? runtime.getCase(artifact.caseId).primaryJob;
    runtime.enterStage({ runId, stageId: "working" });
    const proposal = runtime.createProposal({
      artifactId,
      baseVersion: artifact.canonicalVersion,
      patch: {
        outcome: confirmedOutcome,
        summary: "A bounded, reviewable result is ready. Replace this with the researched domain artifact.",
        status: "proposed",
      },
      rationale: "Demonstrate proposal-before-mutation without assuming a domain.",
    });
    runtime.enterStage({ runId, stageId: "review", nextAction: "Approve or reject the proposed change", nextActionOwner: "user" });
    return proposal;
  }

  function decide({ proposalId, runId, decision }) {
    const result = runtime.decideProposal({ proposalId, decision });
    if (decision === "accepted" && result.proposal.status === "accepted") {
      runtime.enterStage({ runId, stageId: "complete" });
      return { ...result, ...runtime.completeRun({ runId }) };
    }
    // A rejection ends the review as surely as an approval does. Leaving the run parked on the
    // review stage left `run.nextAction` reading "Approve or reject the proposed change" and the
    // stage rail highlighting Review, so the page told the user to decide on a proposal that no
    // longer existed. Both decisions must move the run.
    if (decision === "rejected" && result.proposal.status === "rejected") {
      return { ...result, run: runtime.enterStage({ runId, stageId: "working", nextAction: "Prepare a revised proposal", nextActionOwner: "agent" }) };
    }
    return result;
  }

  return { decide, propose, runtime, start };
}
